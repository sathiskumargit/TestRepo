# Utilities and examples about Alfresco ECM

This repository contains the source code of some java samples which could refer to:

http://www.giuseppeurso.eu

This code and the accompanying materials are made available under the
terms of the GPLv3 license. The GPL (V2 or V3) is a copyleft license that
requires anyone who distributes code or a derivative work to make the
source available under the same terms. V3 is similar to V2, but further
restricts use in hardware that forbids software alterations (see LICENSE.txt).


