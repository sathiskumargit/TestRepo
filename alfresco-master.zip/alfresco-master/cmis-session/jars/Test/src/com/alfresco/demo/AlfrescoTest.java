package com.alfresco.demo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import org.apache.chemistry.opencmis.client.api.Document;
import org.apache.chemistry.opencmis.client.api.Folder;
import org.apache.chemistry.opencmis.client.api.Session;
import org.apache.chemistry.opencmis.client.api.SessionFactory;
import org.apache.chemistry.opencmis.client.runtime.SessionFactoryImpl;
import org.apache.chemistry.opencmis.commons.PropertyIds;
import org.apache.chemistry.opencmis.commons.SessionParameter;
import org.apache.chemistry.opencmis.commons.data.ContentStream;
import org.apache.chemistry.opencmis.commons.enums.BindingType;
import org.apache.chemistry.opencmis.commons.impl.dataobjects.ContentStreamImpl;


public class AlfrescoTest {

   public static void main(String[] args) throws UnsupportedEncodingException {
	   load();
   }
	   
	   public static void txtFile(String[] args) throws UnsupportedEncodingException {
	   
      Map<String, String> sessionParameters = new HashMap<String, String>();
      sessionParameters.put(SessionParameter.USER, "admin");
      sessionParameters.put(SessionParameter.PASSWORD, "admin");
      sessionParameters.put(SessionParameter.ATOMPUB_URL, "http://localhost:8080/alfresco/api/-default-/public/cmis/versions/1.1/atom");
      sessionParameters.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
      SessionFactory sessionFactory = SessionFactoryImpl.newInstance();
      Session lSession = sessionFactory.getRepositories(sessionParameters).get(0).createSession();
      
      Folder root = lSession.getRootFolder();
                Map<String, Object> folderProperties = new HashMap<String, Object>();
                folderProperties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
                folderProperties.put(PropertyIds.NAME, "testfolder1");
                Folder newFolder = root.createFolder(folderProperties);
      Map<String, Object> lProperties = new HashMap<String, Object>();
      String name = "testdocument11.txt";
      lProperties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
      lProperties.put(PropertyIds.NAME, name);
      byte[] content = "CMIS Testdata One".getBytes();
                InputStream stream = new ByteArrayInputStream(content);
                ContentStream contentStream = new ContentStreamImpl(name, new BigInteger(content), "text/plain", stream);
                Document newContent1 =  newFolder.createDocument(lProperties, contentStream, null);
      System.out.println("Document created: " + newContent1.getId());
   }
   
   
   
   public static void load()  {
	   try {
	      Map<String, String> sessionParameters = new HashMap<String, String>();
	      sessionParameters.put(SessionParameter.USER, "admin");
	      sessionParameters.put(SessionParameter.PASSWORD, "admin");
	      sessionParameters.put(SessionParameter.ATOMPUB_URL, "http://localhost:8080/alfresco/api/-default-/public/cmis/versions/1.1/atom");
	      sessionParameters.put(SessionParameter.BINDING_TYPE, BindingType.ATOMPUB.value());
	      SessionFactory sessionFactory = SessionFactoryImpl.newInstance();
	      Session lSession = sessionFactory.getRepositories(sessionParameters).get(0).createSession();
	      
	      Folder root = lSession.getRootFolder();
	                Map<String, Object> folderProperties = new HashMap<String, Object>();
	                folderProperties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:folder");
	                folderProperties.put(PropertyIds.NAME, "testfolder2");
	                Folder newFolder = root.createFolder(folderProperties);
	      Map<String, Object> lProperties = new HashMap<String, Object>();
	      String name = "testdocument.txt";
	      lProperties.put(PropertyIds.OBJECT_TYPE_ID, "cmis:document");
	      lProperties.put(PropertyIds.NAME, name);
	      byte[] content = "CMIS Testdata One".getBytes();
	                InputStream stream = new ByteArrayInputStream(content);
	                ContentStream contentStream = new ContentStreamImpl(name, new BigInteger(content), "text/plain", stream);

	                Document newContent1 =  newFolder.createDocument(lProperties, contentStream, null);
	      System.out.println("Document created: " + newContent1.getId());  
	                File file = new File("c:/Soft/Sample.pdf");
	                ContentStream contentStream1 = lSession.getObjectFactory().
	                		  createContentStream(
	                		    file.getName(),
	                		    file.length(),
	                		    "application/pdf",
	                		    new FileInputStream(file)
	                		  );
	                lProperties.put(PropertyIds.NAME, "JMSample.pdf");
	                Document newContent2 =  newFolder.createDocument(lProperties, contentStream1, null);
	      	      System.out.println("Document created: " + newContent1.getId());  
	   }catch(Exception e) {
		   System.out.println(e);
	   }
	   }
	   
   
   
   
   
}
